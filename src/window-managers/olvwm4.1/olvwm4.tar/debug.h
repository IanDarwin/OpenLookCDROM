#ifdef IDENT
#ident  "@(#)debug.h	1.4    93/06/28 SMI"
#endif
 
/*
 *      (c) Copyright 1989 Sun Microsystems, Inc.
 */

/*
 *      Sun design patents pending in the U.S. and foreign countries. See
 *      LEGAL_NOTICE file for terms of the license.
 */

#ifndef _OLWM_DEBUG_H
#define _OLWM_DEBUG_H

extern void DebugEvent();
extern void DebugWindow();

#endif /* _OLWM_DEBUG_H */
