/*
*    SCCS ID: %Z%%M% %I% %E% SMI 
*
*    Copyright (c) 1992 Sun Microsystems, Inc.  All rights reserved.
*    See LEGAL_NOTICE file for terms of the license.
*/

#define COLOR_CHOOSER	0
#define FILE_CHOOSER	1
